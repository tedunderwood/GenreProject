Genre Project Browser README:

Requirements: Java 1.6, a metadata seed file, allowable genre codes file (optional)

Installation and First Time Use:
To install, place the jar file in the directory you'd like the browser to create its database and configuration files.  The first time that the program is executed, it will prompt users for a metadata seed file and to name the database that will be created from it.  The browser will then populate the database from the seed file.  This can take anywhere from 5 to 15 minutes depending on the speed of the drive you're running the program from.  Currently, there is no progress monitor (and on a Windows machine, there will be no icon to indicate the program is still running).  The browser window will load once the database is populated.  When you exit the program, it should write a configuration file that will keep track of the database and make note of which file was used to populate it.

IMPORTANT: The browser must be exited from the window close button (red dot in the upper left on Mac, 'x' in the upper right on Windows). Forcing it closed using hotkeys or the MacOS application menu will not trigger the close listener that resets the database to its default state or update the configuration file.  If not closed properly, the database may become unstable, although closing it properly in future sessions should cause the database to reset correctly. (In other words, if you forget to close it properly, run it and then close it the correct way immediately.  Things should reset).

Working with Predictions:
Users can load source predictions from ARFF files by clicking the "Load" button in the upper row.  Once a source prediction is loaded, users can perform searches within the source's records using the search interface in the lower portion of the browser by clicking the "Limit to Predictions" option.  Users can also transfer all records from the source prediction to the target prediction by clicking "Load Source Records."

Users can create new ("target") predictions and save them to ARFF files by adding records to the prediction table visible in the upper half of the browser.  Records can either be transferred from a source prediction ARFF file (see above) or selected using the search interface in the lower half of the browser.  Before adding records to a new target, users should "Create" the target in memory.  Clicking "Create" will also prompt users for a save location.  Any further clicks to that button will save to disk until the target is cleared from memory.  If a created target prediction has been modified, an asterisk will appear on the button.

To modify a target prediction's data, use the buttons along the middle of the window. By default, the browser will populate a prediction with generic header data. Setting a record in the target prediction as a "Match" will give it a probability of 1.0.  Setting it as a "Miss" will give it a probability of 0.0.

Working with Page Maps:
In order to use the page mapper, users will need a list of allowable genre codes and labels.  Upon first loading the page mapper, users will be prompted for a directory containing the volume text files for a mapping session.  This choice will be remembered until the Genre Browser is closed.  Users will also be prompted for a genre codes file.  This choice will be remembered and stored in the browser's configuration file for future sessions.  All completed page maps will be stored in the browser's local directory in a subdirectory "pagemaps/" (created by the browser as needed).
